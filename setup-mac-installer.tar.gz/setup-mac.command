#!/usr/bin/env bash
#
# setup-mac.command — Install Claude Code and its prerequisites on macOS.
#
# Sibling to setup-mcp.bat. Does NOT install uv, Python 3.12, or any
# unreal-mcp dependencies. Just Git (via Xcode CLT), Node.js (>=18),
# and Claude Code itself.
#
# Usage:
#   - Double-click this file in Finder. macOS recognizes the .command
#     extension and runs it in Terminal.app automatically.
#   - Or from a terminal:  bash setup-mac.command
#
# First-time setup on a fresh checkout: you must mark this file
# executable once before double-click will work. From a terminal:
#     chmod +x setup-mac.command
#
# Re-run safe: if a step is already complete it is skipped.
# IMPORTANT: this file MUST have Unix (LF) line endings to run on macOS.

set -uo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOGFILE="$SCRIPT_DIR/setup-mac.log"
NODE_MIN_MAJOR=18

# Exit codes
EX_OK=0
EX_FAIL=1
EX_TEMPFAIL=75   # "needs another step / new shell — re-run me"

# Set by ensure_brew_on_path() if it discovers an existing Homebrew
# install that wasn't on the user's shell PATH. Used to print a
# permanent-fix tip in the final summary.
BREW_BIN=""
BREW_WAS_ORPHANED=0

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

log() {
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  printf '[%s] %s\n' "$ts" "$*" >> "$LOGFILE"
}

say() {
  printf '%s\n' "$*"
  log "$*"
}

die() {
  printf '\nERROR: %s\n' "$*" >&2
  log "FATAL: $*"
  exit "$EX_FAIL"
}

have() { command -v "$1" >/dev/null 2>&1; }

# prompt_yn "question" default(Y|N) — returns 0 for yes, 1 for no.
prompt_yn() {
  local q="$1" default="${2:-N}" reply hint="[y/N]"
  [ "$default" = "Y" ] && hint="[Y/n]"
  printf '%s %s ' "$q" "$hint"
  read -r reply || reply=""
  reply="$(printf '%s' "$reply" | tr '[:upper:]' '[:lower:]')"
  if [ -z "$reply" ]; then
    [ "$default" = "Y" ]
  else
    [ "$reply" = "y" ] || [ "$reply" = "yes" ]
  fi
}

# Print Node's major version, or empty if missing/unparseable.
node_major() {
  have node || { printf ''; return; }
  local v
  v="$(node -v 2>/dev/null)" || { printf ''; return; }
  v="${v#v}"
  printf '%s' "${v%%.*}"
}

# Look for `brew` at the canonical install paths even when it's not on
# the current shell's PATH (a common state when a user installed
# Homebrew but never added the shellenv line to ~/.zprofile). If found,
# source its shellenv into THIS shell process so subsequent `brew` and
# `node` calls work, and remember that we did so for the final tip.
#
# Returns 0 if brew is now usable (whether already-on-PATH or just-sourced),
# 1 if no Homebrew install exists anywhere we know to look.
ensure_brew_on_path() {
  if have brew; then
    BREW_BIN="$(command -v brew)"
    return 0
  fi
  local candidate
  for candidate in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    if [ -x "$candidate" ]; then
      log "Found orphaned Homebrew at $candidate -- sourcing shellenv"
      eval "$("$candidate" shellenv)"
      BREW_BIN="$candidate"
      BREW_WAS_ORPHANED=1
      say "   Found existing Homebrew at $candidate (not on your shell PATH -- sourcing it now)."
      return 0
    fi
  done
  return 1
}

# Append the canonical `eval "$(brew shellenv)"` line to ~/.zprofile so
# Homebrew is available in all future login shells. macOS Terminal.app
# starts every new tab as a login shell, so .zprofile is the right file
# (not .zshrc, which is for interactive subshells and would re-run on
# every nested shell).
#
# Idempotent: if a `brew shellenv` line is already in the file (perhaps
# from a previous run, or added by hand), do nothing.
add_brew_to_zprofile() {
  local rc="$HOME/.zprofile"
  local line
  line=$(printf 'eval "$(%s shellenv)"' "$BREW_BIN")

  if ! touch "$rc" 2>/dev/null; then
    say "   ERROR: could not write to $rc (permissions?)."
    return 1
  fi

  if grep -qF 'brew shellenv' "$rc" 2>/dev/null; then
    say "   A 'brew shellenv' line is already present in $rc -- leaving it alone."
    return 0
  fi

  {
    printf '\n# Added by setup-mac.command on %s\n' "$(date '+%Y-%m-%d')"
    printf '%s\n' "$line"
  } >> "$rc" || { say "   ERROR: failed to append to $rc."; return 1; }

  say "   Added to $rc."
  say "   It will take effect in every NEW terminal window you open."
}

# ──────────────────────────────────────────────
# Pre-flight
# ──────────────────────────────────────────────

: > "$LOGFILE"
log "Setup started"
log "User:   ${USER:-unknown}"
log "Host:   $(hostname 2>/dev/null || printf unknown)"
log "macOS:  $(sw_vers -productVersion 2>/dev/null || printf unknown)"
log "Arch:   $(uname -m)"
log "Script: $0"

cat <<'BANNER'
============================================
 ZooKeepers - Mac Dev Environment Setup
============================================
 Installs: Git (via Xcode CLT), Node.js LTS,
 and Claude Code.
============================================

BANNER

say "Checking internet connectivity..."
if curl -fsSL --max-time 5 -o /dev/null https://nodejs.org; then
  say "   Connected."
else
  say "   WARNING: Could not reach nodejs.org. Continuing anyway..."
fi
echo

# ──────────────────────────────────────────────
# Step 1 — Git (via Xcode Command Line Tools)
# ──────────────────────────────────────────────

if have git; then
  say "[1/4] $(git --version) already installed."
else
  say "[1/4] Git not found. Triggering Xcode Command Line Tools install..."
  xcode-select --install >/dev/null 2>&1 || true
  cat <<'XCODE_MSG'

   A macOS dialog should have appeared asking you to install
   the Command Line Developer Tools. (If you don't see it,
   check behind other windows or look for it in the Dock.)

   1. Click "Install" and accept the license.
   2. Wait for it to finish (a few minutes).
   3. Re-run this script (double-click setup-mac.command in Finder,
      or run:  bash setup-mac.command).

   NOTE: 'xcode-select --install' returns immediately to your
   shell prompt -- the actual install happens in that GUI dialog,
   not in this terminal. That is normal.

XCODE_MSG
  log "Git missing -- instructed user to complete Xcode CLT install"
  exit "$EX_TEMPFAIL"
fi

# ──────────────────────────────────────────────
# Step 2 — Node.js (>= 18)
# ──────────────────────────────────────────────

install_node_via_brew() {
  say "   Installing Node.js via Homebrew..."
  brew install node 2>&1 | tee -a "$LOGFILE"
}

install_homebrew() {
  # NOTE: We deliberately do NOT pipe `curl` straight into `bash` (the
  # canonical `curl ... | bash` Homebrew one-liner). Piping a remote
  # script directly into a shell gives a network attacker on the path
  # the ability to inject arbitrary commands without ever leaving an
  # artifact on disk for the user to inspect. Homebrew does not publish
  # a stable checksum for install.sh (it changes frequently), so the
  # best we can do is download it to a known temp file first, then
  # execute that file. The user can `cat` the printed path to inspect.
  local installer_url="https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh"
  local installer rc
  installer="$(mktemp -t homebrew-install)" || { log "mktemp failed"; return 1; }

  say "   Downloading the official Homebrew installer..."
  if ! curl -fsSL -o "$installer" "$installer_url"; then
    log "Homebrew installer download failed from $installer_url"
    rm -f "$installer"
    return 1
  fi
  say "   Saved to: $installer"
  say "   Running it now (you will be prompted for your sudo password)..."

  /bin/bash "$installer" 2>&1 | tee -a "$LOGFILE"
  rc=$?
  rm -f "$installer"
  if [ "$rc" -ne 0 ]; then
    log "Homebrew installer exited $rc"
    return "$rc"
  fi

  # Source the freshly-installed brew shellenv into THIS shell so the
  # rest of the script can call `brew` without a shell restart.
  if   [ -x /opt/homebrew/bin/brew ]; then eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [ -x /usr/local/bin/brew    ]; then eval "$(/usr/local/bin/brew shellenv)"
  fi
  have brew
}

install_node_via_pkg() {
  say "   Falling back to direct .pkg download from nodejs.org..."

  if ! have python3; then
    die "python3 is required to fetch the Node.js manifest. Run 'xcode-select --install' first, then re-run this script."
  fi

  local version pkg_name pkg_url shasums tmpdir expected actual
  version="$(curl -fsSL https://nodejs.org/dist/index.json \
    | python3 -c '
import json, sys
data = json.load(sys.stdin)
for r in data:
    if r.get("lts"):
        print(r["version"])
        break
')" || die "Failed to fetch Node.js release manifest from nodejs.org."
  [ -n "$version" ] || die "Could not determine latest Node.js LTS version."

  pkg_name="node-${version}.pkg"
  pkg_url="https://nodejs.org/dist/${version}/${pkg_name}"
  log "Latest LTS: $version"
  say "   Latest LTS is $version"

  tmpdir="$(mktemp -d -t setup-mac-node)"

  say "   Downloading $pkg_name..."
  if ! curl -fL --progress-bar -o "$tmpdir/$pkg_name" "$pkg_url"; then
    rm -rf "$tmpdir"
    die "Download failed: $pkg_url"
  fi

  # Verify SHA-256 against the official SHASUMS256.txt before installing.
  # This is a real supply-chain check, not just download integrity --
  # it would catch a swapped binary on a compromised mirror.
  say "   Verifying checksum..."
  shasums="$(curl -fsSL "https://nodejs.org/dist/${version}/SHASUMS256.txt")" \
    || { rm -rf "$tmpdir"; die "Failed to fetch SHASUMS256.txt"; }
  expected="$(printf '%s\n' "$shasums" | awk -v f="$pkg_name" '$2==f {print $1}')"
  [ -n "$expected" ] || { rm -rf "$tmpdir"; die "No checksum found for $pkg_name in SHASUMS256.txt"; }
  actual="$(shasum -a 256 "$tmpdir/$pkg_name" | awk '{print $1}')"
  if [ "$expected" != "$actual" ]; then
    rm -rf "$tmpdir"
    die "Checksum MISMATCH for $pkg_name. Expected $expected, got $actual. Aborting install."
  fi
  say "   Checksum OK."

  say "   Installing (you may be prompted for your sudo password)..."
  if ! sudo installer -pkg "$tmpdir/$pkg_name" -target / 2>&1 | tee -a "$LOGFILE"; then
    rm -rf "$tmpdir"
    die "installer failed for $pkg_name"
  fi
  rm -rf "$tmpdir"
}

# Surface any orphaned Homebrew install BEFORE we decide how to install
# Node. This way, if the user installed Homebrew long ago but never set
# up its shellenv, we'll find it and use it -- instead of either (a)
# wastefully running the Homebrew installer just to have it bail with
# "already installed", or (b) installing Node via .pkg side-by-side
# with their existing brew, leaving them with two unrelated Nodes.
ensure_brew_on_path || true

current_major="$(node_major)"
if [ -n "$current_major" ] && [ "$current_major" -ge "$NODE_MIN_MAJOR" ]; then
  say "[2/4] Node.js $(node -v) already installed (>= $NODE_MIN_MAJOR)."
elif [ -n "$current_major" ]; then
  # Strict policy: refuse to silently overwrite an existing Node install.
  # The user almost certainly installed it for another project, and
  # auto-upgrading Node has broken many a workflow.
  say "[2/4] Node.js $(node -v) is too old -- Claude Code needs >= ${NODE_MIN_MAJOR}."
  cat <<EOF

   Your existing Node.js was probably installed for another project.
   This script will NOT silently overwrite it. Please upgrade or
   uninstall it first, then re-run this script.

   Common ways to upgrade:
     - Homebrew:    brew upgrade node      (or 'brew install node' if not from brew)
     - nvm:         nvm install --lts && nvm alias default 'lts/*'
     - Direct .pkg: https://nodejs.org/

EOF
  log "Existing Node.js v$current_major < $NODE_MIN_MAJOR -- refusing to auto-upgrade"
  exit "$EX_FAIL"
else
  say "[2/4] Installing Node.js LTS..."
  if have brew; then
    install_node_via_brew || die "brew install node failed"
  else
    if prompt_yn "   Homebrew is not installed. Install it now?" "N"; then
      if install_homebrew; then
        install_node_via_brew || die "brew install node failed"
      else
        say "   Homebrew install failed -- falling back to direct .pkg download."
        install_node_via_pkg
      fi
    else
      install_node_via_pkg
    fi
  fi

  current_major="$(node_major)"
  if [ -z "$current_major" ] || [ "$current_major" -lt "$NODE_MIN_MAJOR" ]; then
    die "Node.js install reported success but 'node' is missing or still too old."
  fi
  say "   Done -- Node.js $(node -v)."
fi

# ──────────────────────────────────────────────
# Step 3 — Claude Code (via npm)
# ──────────────────────────────────────────────

if ! have npm; then
  die "npm not found even though Node.js is installed. Open a new terminal and re-run this script."
fi

if have claude; then
  say "[3/4] Claude Code already installed ($(claude --version 2>/dev/null || printf 'version unknown'))."
else
  say "[3/4] Installing Claude Code..."
  say "   This may take a minute..."
  if ! npm install -g @anthropic-ai/claude-code 2>&1 | tee -a "$LOGFILE"; then
    cat <<'NPMFAIL'

   ERROR: 'npm install -g @anthropic-ai/claude-code' failed.

   If you saw an EACCES / permission error, your Node was likely
   installed in a way that puts global packages in /usr/local
   without user write access. Two options:

     1. Reinstall Node via Homebrew (recommended), then re-run this script:
          brew install node

     2. Configure a user-writable global prefix:
          mkdir -p "$HOME/.npm-global"
          npm config set prefix "$HOME/.npm-global"
          echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> ~/.zshrc
        Then open a new terminal and re-run this script.

NPMFAIL
    die "npm install -g @anthropic-ai/claude-code failed"
  fi

  if ! have claude; then
    say "   Claude Code installed but 'claude' is not on the PATH for this shell."
    say "   Open a new terminal and re-run this script to verify."
    log "claude installed but not on PATH in current shell"
    exit "$EX_TEMPFAIL"
  fi
  say "   Done."
fi

# ──────────────────────────────────────────────
# Step 4 — Verify
# ──────────────────────────────────────────────

echo
say "[4/4] Verifying..."

ok=1

check() {
  local label="$1" cmd="$2" v
  if v="$(eval "$cmd" 2>/dev/null)"; then
    printf '   [OK]   %-8s %s\n' "$label" "$v"
    log "VERIFY OK: $label $v"
  else
    printf '   [FAIL] %-8s not found\n' "$label"
    log "VERIFY FAIL: $label"
    ok=0
  fi
}

check "git"    "git --version"
check "node"   "node --version"
check "npm"    "npm --version"
check "claude" "claude --version || echo installed"

echo
if [ "$ok" -eq 1 ]; then
  cat <<'DONE'
============================================
 Setup complete! All checks passed.
============================================

 What to do now:
   1. In this terminal, type:  claude
      (first time will ask you to log in)

 If 'claude' is not found, open a new
 terminal window and try again.

 Log saved to: setup-mac.log

DONE

  # If we discovered an orphaned Homebrew install during this run, the
  # user's *future* terminals still won't have brew on PATH unless we
  # add the shellenv line to their shell config. Offer to do it for
  # them. Use an unquoted heredoc so $BREW_BIN expands to the actual
  # path we found.
  if [ "$BREW_WAS_ORPHANED" -eq 1 ]; then
    cat <<EOF
 ------------------------------------------------
 Heads up: Homebrew was installed but not on your
 shell PATH. We sourced it for THIS script, but
 in future terminal windows 'brew' will not be
 found unless we add this line to ~/.zprofile:

     eval "\$($BREW_BIN shellenv)"

EOF
    if prompt_yn " Add it to ~/.zprofile now?" "Y"; then
      add_brew_to_zprofile || say "   You can add it manually later if needed."
    else
      cat <<EOF

   OK, skipping. You can do it yourself any time with:

     echo 'eval "\$($BREW_BIN shellenv)"' >> ~/.zprofile

   (Use ~/.bash_profile instead if you use bash, not zsh.)
EOF
    fi
    echo " ------------------------------------------------"
    echo
  fi
  exit "$EX_OK"
else
  cat <<'BAD'
============================================
 Setup had errors. See messages above.
 Log saved to: setup-mac.log
============================================

BAD
  exit "$EX_FAIL"
fi

#!/usr/bin/env bash
#
# setup-mac.command — Install Claude Code and its prerequisites on macOS.
#
# Sibling to setup-mcp.bat. Does NOT install uv, Python 3.12, or any
# unreal-mcp dependencies. Just Git (via Xcode CLT), Node.js (>=18),
# and Claude Code itself.
#
# Requirements:
#   - macOS 11 (Big Sur) or newer
#   - An internet connection
#   - Run as your normal user (NOT under sudo). The script will prompt
#     for your password only at the specific moments it needs root.
#
# Usage:
#   - Double-click this file in Finder. macOS recognizes the .command
#     extension and runs it in Terminal.app automatically.
#   - Or from a terminal:  bash setup-mac.command
#
# First-time setup on a fresh checkout: you must mark this file
# executable once before double-click will work. From a terminal:
#     chmod +x setup-mac.command
#
# Re-run safe: if a step is already complete it is skipped.
# IMPORTANT: this file MUST have Unix (LF) line endings to run on macOS.

set -uo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOGFILE="$SCRIPT_DIR/setup-mac.log"

# Minimum Node.js major version required by Claude Code.
# Source: the `engines.node` field of @anthropic-ai/claude-code's
# package.json (check npmjs.com or `npm view @anthropic-ai/claude-code engines`).
# Bump this if Claude Code raises its minimum.
NODE_MIN_MAJOR=18

# Minimum macOS major version. Tied to Node 18+ binary support
# (Node 18 requires macOS 11 Big Sur). Bump if NODE_MIN_MAJOR rises.
MACOS_MIN_MAJOR=11

# Exit codes
EX_OK=0
EX_FAIL=1
EX_TEMPFAIL=75   # "needs another step / new shell — re-run me"

# Set by ensure_brew_on_path() if it discovers an existing Homebrew
# install that wasn't on the user's shell PATH. Used to print a
# permanent-fix tip in the final summary.
BREW_BIN=""
BREW_WAS_ORPHANED=0

# Detect the user's login shell so we can write the brew shellenv line
# into the right startup file. macOS Terminal.app starts every new
# window as a login shell, which means:
#   - zsh users → ~/.zprofile  (zsh's login-shell file)
#   - bash users → ~/.bash_profile
# Set once here, used by add_brew_to_shell_rc() and the final tip.
SHELL_NAME="$(basename "${SHELL:-/bin/zsh}")"
case "$SHELL_NAME" in
  zsh)  RC_FILE="$HOME/.zprofile" ;;
  bash) RC_FILE="$HOME/.bash_profile" ;;
  *)    RC_FILE="$HOME/.zprofile" ;;  # fish/unknown -- best-effort fallback
esac

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

log() {
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  printf '[%s] %s\n' "$ts" "$*" >> "$LOGFILE"
}

say() {
  printf '%s\n' "$*"
  log "$*"
}

die() {
  printf '\nERROR: %s\n' "$*" >&2
  log "FATAL: $*"
  exit "$EX_FAIL"
}

have() { command -v "$1" >/dev/null 2>&1; }

# prompt_yn "question" default(Y|N) — returns 0 for yes, 1 for no.
prompt_yn() {
  local q="$1" default="${2:-N}" reply hint="[y/N]"
  [ "$default" = "Y" ] && hint="[Y/n]"
  printf '%s %s ' "$q" "$hint"
  read -r reply || reply=""
  reply="$(printf '%s' "$reply" | tr '[:upper:]' '[:lower:]')"
  if [ -z "$reply" ]; then
    [ "$default" = "Y" ]
  else
    [ "$reply" = "y" ] || [ "$reply" = "yes" ]
  fi
}

# Print Node's major version, or empty if missing/unparseable.
node_major() {
  have node || { printf ''; return; }
  local v
  v="$(node -v 2>/dev/null)" || { printf ''; return; }
  v="${v#v}"
  printf '%s' "${v%%.*}"
}

# Look for `brew` at the canonical install paths even when it's not on
# the current shell's PATH (a common state when a user installed
# Homebrew but never added the shellenv line to ~/.zprofile). If found,
# source its shellenv into THIS shell process so subsequent `brew` and
# `node` calls work, and remember that we did so for the final tip.
#
# Returns 0 if brew is now usable (whether already-on-PATH or just-sourced),
# 1 if no Homebrew install exists anywhere we know to look.
ensure_brew_on_path() {
  if have brew; then
    BREW_BIN="$(command -v brew)"
    return 0
  fi
  local candidate
  for candidate in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    if [ -x "$candidate" ]; then
      log "Found orphaned Homebrew at $candidate -- sourcing shellenv"
      eval "$("$candidate" shellenv)"
      BREW_BIN="$candidate"
      BREW_WAS_ORPHANED=1
      say "   Found existing Homebrew at $candidate (not on your shell PATH -- sourcing it now)."
      return 0
    fi
  done
  return 1
}

# Append the canonical `eval "$(brew shellenv)"` line to the user's
# shell login config (the file picked by SHELL_NAME -> RC_FILE earlier),
# so Homebrew is available in all future terminal windows. macOS
# Terminal.app starts every new tab as a login shell, which is why we
# write to the *login* startup file (.zprofile / .bash_profile), not
# the *interactive* one (.zshrc / .bashrc) -- the latter would re-run
# `eval` on every nested shell, wasting cycles and duplicating PATH.
#
# Idempotent: if a `brew shellenv` line is already in the file (perhaps
# from a previous run, or added by hand), do nothing.
add_brew_to_shell_rc() {
  local line
  line=$(printf 'eval "$(%s shellenv)"' "$BREW_BIN")

  if ! touch "$RC_FILE" 2>/dev/null; then
    say "   ERROR: could not write to $RC_FILE (permissions?)."
    return 1
  fi

  if grep -qF 'brew shellenv' "$RC_FILE" 2>/dev/null; then
    say "   A 'brew shellenv' line is already present in $RC_FILE -- leaving it alone."
    return 0
  fi

  {
    printf '\n# Added by setup-mac.command on %s\n' "$(date '+%Y-%m-%d')"
    printf '%s\n' "$line"
  } >> "$RC_FILE" || { say "   ERROR: failed to append to $RC_FILE."; return 1; }

  say "   Added to $RC_FILE."
  say "   It will take effect in every NEW terminal window you open."
}

# ──────────────────────────────────────────────
# Pre-flight
# ──────────────────────────────────────────────

# Guard: macOS only. Refuse to run on Linux/WSL/anything else where the
# install paths and tools (`xcode-select`, `installer`, `sw_vers`,
# `/opt/homebrew`, etc.) don't exist or behave differently.
if [ "$(uname -s)" != "Darwin" ]; then
  printf '\nERROR: This script is macOS-only. Detected platform: %s\n' "$(uname -s)" >&2
  printf 'Use setup-mcp.bat on Windows.\n' >&2
  exit 1
fi

# Guard: must NOT be running as root. Running this under sudo would
# create root-owned files (~/.npm cache, the log file, and any rc-file
# entries we add) that silently break the user's normal account afterward.
# The script will sudo individual commands when it actually needs root.
if [ "${EUID:-$(id -u)}" -eq 0 ]; then
  printf '\nERROR: Do NOT run this script with sudo or as root.\n' >&2
  printf 'Run it as your normal user. The script will prompt for your password\n' >&2
  printf 'only at the moments it actually needs root (Node .pkg install, brew).\n' >&2
  exit 1
fi

# Guard: macOS version. Node 18+ binary support starts at macOS 11.
macos_full="$(sw_vers -productVersion 2>/dev/null || printf unknown)"
macos_major="$(printf '%s' "$macos_full" | cut -d. -f1)"
case "$macos_major" in
  ''|*[!0-9]*)
    printf '\nWARNING: Could not determine macOS version (%s). Continuing anyway.\n' "$macos_full" >&2
    ;;
  *)
    if [ "$macos_major" -lt "$MACOS_MIN_MAJOR" ]; then
      printf '\nERROR: macOS %d (Big Sur) or newer required. You are on %s.\n' \
        "$MACOS_MIN_MAJOR" "$macos_full" >&2
      printf 'Node.js %d+ does not support older macOS releases.\n' "$NODE_MIN_MAJOR" >&2
      exit 1
    fi
    ;;
esac

# Strip the quarantine xattr from the script itself if present, so re-runs
# don't repeatedly trip Gatekeeper after a download. Best-effort -- if it
# fails (already absent, or no xattr command for some reason), no harm.
if [ -f "$SCRIPT_DIR/setup-mac.command" ]; then
  xattr -d com.apple.quarantine "$SCRIPT_DIR/setup-mac.command" 2>/dev/null || true
fi

# Rotate the previous log file instead of truncating it. Keeps exactly
# one prior run around (setup-mac.log.prev) so a teammate sending us a
# bug report has both the failing run and the prior context.
if [ -f "$LOGFILE" ]; then
  mv -f "$LOGFILE" "${LOGFILE}.prev" 2>/dev/null || true
fi
: > "$LOGFILE"

log "Setup started"
log "User:   ${USER:-unknown}"
log "Host:   $(hostname 2>/dev/null || printf unknown)"
log "macOS:  $macos_full"
log "Arch:   $(uname -m)"
log "Shell:  $SHELL_NAME ($RC_FILE)"
log "Script: $0"

cat <<'BANNER'
============================================
 ZooKeepers - Mac Dev Environment Setup
============================================
 Installs: Git (via Xcode CLT), Node.js LTS,
 and Claude Code.
============================================

BANNER

say "Checking internet connectivity..."
if curl -fsSL --max-time 5 --retry 2 --retry-delay 1 -o /dev/null https://nodejs.org; then
  say "   Connected."
else
  say "   WARNING: Could not reach nodejs.org. Continuing anyway..."
fi
echo

# ──────────────────────────────────────────────
# Step 1 — Git (via Xcode Command Line Tools)
# ──────────────────────────────────────────────

if have git; then
  say "[1/4] $(git --version) already installed."
else
  say "[1/4] Git not found. Triggering Xcode Command Line Tools install..."
  xcode-select --install >/dev/null 2>&1 || true
  cat <<'XCODE_MSG'

   A macOS dialog should have appeared asking you to install
   the Command Line Developer Tools. (If you don't see it,
   check behind other windows or look for it in the Dock.)

   1. Click "Install" and accept the license.
   2. Wait for it to finish (a few minutes).
   3. Re-run this script (double-click setup-mac.command in Finder,
      or run:  bash setup-mac.command).

   NOTE: 'xcode-select --install' returns immediately to your
   shell prompt -- the actual install happens in that GUI dialog,
   not in this terminal. That is normal.

XCODE_MSG
  log "Git missing -- instructed user to complete Xcode CLT install"
  exit "$EX_TEMPFAIL"
fi

# ──────────────────────────────────────────────
# Step 2 — Node.js (>= 18)
# ──────────────────────────────────────────────

install_node_via_brew() {
  # We deliberately install the unversioned `node` formula (latest LTS
  # at the time brew last updated). This tracks Homebrew's "current
  # recommended Node" rather than pinning to a specific major. The
  # trade-off:
  #   + Always gets a maintained, security-patched Node.
  #   - May install a Node *newer* than Claude Code supports if Claude
  #     Code's compatibility lags. If that ever happens, change this
  #     to a versioned formula like `node@22` (or whatever Claude Code's
  #     supported LTS is at that moment) and bump NODE_MIN_MAJOR.
  say "   Installing Node.js via Homebrew (formula: node)..."
  brew install node 2>&1 | tee -a "$LOGFILE"
}

install_homebrew() {
  # NOTE: We deliberately do NOT pipe `curl` straight into `bash` (the
  # canonical `curl ... | bash` Homebrew one-liner). Piping a remote
  # script directly into a shell gives a network attacker on the path
  # the ability to inject arbitrary commands without ever leaving an
  # artifact on disk for the user to inspect. Homebrew does not publish
  # a stable checksum for install.sh (it changes frequently), so the
  # best we can do is download it to a known temp file first, then
  # execute that file. The user can `cat` the printed path to inspect.
  local installer_url="https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh"
  local installer rc
  installer="$(mktemp -t homebrew-install)" || { log "mktemp failed"; return 1; }

  say "   Downloading the official Homebrew installer..."
  if ! curl -fsSL --retry 3 --retry-delay 2 -o "$installer" "$installer_url"; then
    log "Homebrew installer download failed from $installer_url"
    rm -f "$installer"
    return 1
  fi
  say "   Saved to: $installer"
  say "   Running it now (you will be prompted for your sudo password)..."

  /bin/bash "$installer" 2>&1 | tee -a "$LOGFILE"
  rc=$?
  rm -f "$installer"
  if [ "$rc" -ne 0 ]; then
    log "Homebrew installer exited $rc"
    return "$rc"
  fi

  # Source the freshly-installed brew shellenv into THIS shell so the
  # rest of the script can call `brew` without a shell restart.
  if   [ -x /opt/homebrew/bin/brew ]; then eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [ -x /usr/local/bin/brew    ]; then eval "$(/usr/local/bin/brew shellenv)"
  fi
  have brew
}

install_node_via_pkg() {
  say "   Falling back to direct .pkg download from nodejs.org..."

  # python3 is used below to parse Node's release manifest JSON.
  # Chain of assumptions: by the time we reach this function, Step 1
  # has verified `git`, which on macOS only exists if Xcode Command
  # Line Tools are installed (xcode-select). CLT installs python3 to
  # /usr/bin/python3, so this should always succeed in practice.
  # Defended against the edge case (git installed via brew, no CLT).
  if ! have python3; then
    die "python3 is required to fetch the Node.js manifest. Run 'xcode-select --install' first, then re-run this script."
  fi

  local version pkg_name pkg_url shasums tmpdir expected actual
  version="$(curl -fsSL --retry 3 --retry-delay 2 https://nodejs.org/dist/index.json \
    | python3 -c '
import json, sys
data = json.load(sys.stdin)
for r in data:
    if r.get("lts"):
        print(r["version"])
        break
')" || die "Failed to fetch Node.js release manifest from nodejs.org."
  [ -n "$version" ] || die "Could not determine latest Node.js LTS version."

  pkg_name="node-${version}.pkg"
  pkg_url="https://nodejs.org/dist/${version}/${pkg_name}"
  log "Latest LTS: $version"
  say "   Latest LTS is $version"

  tmpdir="$(mktemp -d -t setup-mac-node)"
  # Cleanup traps cover normal exit, errors, and signals (Ctrl+C).
  # Notes on the design here:
  #   - The `${tmpdir:-}` guard makes the trap safe even if it fires
  #     after the function has returned and the local `tmpdir` is out
  #     of scope. Without the guard, set -u would turn the trap into
  #     an "unbound variable" error that masks the script's real exit
  #     code. (Bash traps are global, not function-local, even if the
  #     variables they reference are local.)
  #   - INT and TERM each have their own trap that explicitly exits.
  #     Without that, a default-behavior `trap '...' INT` would run
  #     the cleanup and then *continue* the script, which is the
  #     opposite of what Ctrl+C should do. Exit codes 130/143 follow
  #     the standard convention (128 + signal number).
  #   - The traps are disarmed at the end of the function on success
  #     so they don't fire on the script's later normal exit.
  trap '[ -n "${tmpdir:-}" ] && rm -rf "$tmpdir"' EXIT
  trap '[ -n "${tmpdir:-}" ] && rm -rf "$tmpdir"; exit 130' INT
  trap '[ -n "${tmpdir:-}" ] && rm -rf "$tmpdir"; exit 143' TERM

  say "   Downloading $pkg_name..."
  if ! curl -fL --progress-bar --retry 3 --retry-delay 2 -o "$tmpdir/$pkg_name" "$pkg_url"; then
    die "Download failed: $pkg_url"
  fi

  # Verify SHA-256 against the official SHASUMS256.txt before installing.
  # This is a real supply-chain check, not just download integrity --
  # it would catch a swapped binary on a compromised mirror.
  say "   Verifying checksum..."
  shasums="$(curl -fsSL --retry 3 --retry-delay 2 "https://nodejs.org/dist/${version}/SHASUMS256.txt")" \
    || die "Failed to fetch SHASUMS256.txt"
  expected="$(printf '%s\n' "$shasums" | awk -v f="$pkg_name" '$2==f {print $1}')"
  [ -n "$expected" ] || die "No checksum found for $pkg_name in SHASUMS256.txt"
  actual="$(shasum -a 256 "$tmpdir/$pkg_name" | awk '{print $1}')"
  if [ "$expected" != "$actual" ]; then
    die "Checksum MISMATCH for $pkg_name. Expected $expected, got $actual. Aborting install."
  fi
  say "   Checksum OK."

  say "   Installing (you may be prompted for your sudo password)..."
  if ! sudo installer -pkg "$tmpdir/$pkg_name" -target / 2>&1 | tee -a "$LOGFILE"; then
    die "installer failed for $pkg_name"
  fi

  # Success path: clean up and disarm the traps so they don't fire
  # later when $tmpdir is gone.
  rm -rf "$tmpdir"
  trap - EXIT INT TERM
}

# Surface any orphaned Homebrew install BEFORE we decide how to install
# Node. This way, if the user installed Homebrew long ago but never set
# up its shellenv, we'll find it and use it -- instead of either (a)
# wastefully running the Homebrew installer just to have it bail with
# "already installed", or (b) installing Node via .pkg side-by-side
# with their existing brew, leaving them with two unrelated Nodes.
ensure_brew_on_path || true

current_major="$(node_major)"
if [ -n "$current_major" ] && [ "$current_major" -ge "$NODE_MIN_MAJOR" ]; then
  say "[2/4] Node.js $(node -v) already installed (>= $NODE_MIN_MAJOR)."
elif [ -n "$current_major" ]; then
  # Strict policy: refuse to silently overwrite an existing Node install.
  # The user almost certainly installed it for another project, and
  # auto-upgrading Node has broken many a workflow.
  say "[2/4] Node.js $(node -v) is too old -- Claude Code needs >= ${NODE_MIN_MAJOR}."
  cat <<EOF

   Your existing Node.js was probably installed for another project.
   This script will NOT silently overwrite it. Please upgrade or
   uninstall it first, then re-run this script.

   Common ways to upgrade:
     - Homebrew:    brew upgrade node      (or 'brew install node' if not from brew)
     - nvm:         nvm install --lts && nvm alias default 'lts/*'
     - Direct .pkg: https://nodejs.org/

EOF
  log "Existing Node.js v$current_major < $NODE_MIN_MAJOR -- refusing to auto-upgrade"
  exit "$EX_FAIL"
else
  say "[2/4] Installing Node.js LTS..."
  if have brew; then
    install_node_via_brew || die "brew install node failed"
  else
    if prompt_yn "   Homebrew is not installed. Install it now?" "N"; then
      if install_homebrew; then
        install_node_via_brew || die "brew install node failed"
      else
        say "   Homebrew install failed -- falling back to direct .pkg download."
        install_node_via_pkg
      fi
    else
      install_node_via_pkg
    fi
  fi

  current_major="$(node_major)"
  if [ -z "$current_major" ] || [ "$current_major" -lt "$NODE_MIN_MAJOR" ]; then
    die "Node.js install reported success but 'node' is missing or still too old."
  fi
  say "   Done -- Node.js $(node -v)."
fi

# ──────────────────────────────────────────────
# Step 3 — Claude Code (via npm)
# ──────────────────────────────────────────────

if ! have npm; then
  die "npm not found even though Node.js is installed. Open a new terminal and re-run this script."
fi

if have claude; then
  say "[3/4] Claude Code already installed ($(claude --version 2>/dev/null || printf 'version unknown'))."
else
  say "[3/4] Installing Claude Code..."
  say "   This may take a minute..."
  if ! npm install -g @anthropic-ai/claude-code 2>&1 | tee -a "$LOGFILE"; then
    cat <<'NPMFAIL'

   ERROR: 'npm install -g @anthropic-ai/claude-code' failed.

   If you saw an EACCES / permission error, your Node's global
   packages directory isn't writable by your user. The directory
   depends on how Node was installed:
     - Apple Silicon Homebrew:  /opt/homebrew/lib/node_modules
     - Intel Homebrew:          /usr/local/lib/node_modules
     - Direct .pkg installer:   /usr/local/lib/node_modules
     - nvm:                     ~/.nvm/versions/node/<ver>/lib/node_modules

   Two ways to fix:

     1. Reinstall Node via Homebrew (recommended -- brew installs
        into a user-writable prefix), then re-run this script:
          brew install node

     2. Configure a user-writable global prefix:
          mkdir -p "$HOME/.npm-global"
          npm config set prefix "$HOME/.npm-global"
          echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> ~/.zprofile
        Then open a new terminal and re-run this script.

NPMFAIL
    die "npm install -g @anthropic-ai/claude-code failed"
  fi

  if ! have claude; then
    say "   Claude Code installed but 'claude' is not on the PATH for this shell."
    say "   Open a new terminal and re-run this script to verify."
    log "claude installed but not on PATH in current shell"
    exit "$EX_TEMPFAIL"
  fi
  say "   Done."
fi

# ──────────────────────────────────────────────
# Step 4 — Verify
# ──────────────────────────────────────────────

echo
say "[4/4] Verifying..."

ok=1

check() {
  local label="$1" cmd="$2" v
  if v="$(eval "$cmd" 2>/dev/null)"; then
    printf '   [OK]   %-8s %s\n' "$label" "$v"
    log "VERIFY OK: $label $v"
  else
    printf '   [FAIL] %-8s not found\n' "$label"
    log "VERIFY FAIL: $label"
    ok=0
  fi
}

check "git"    "git --version"
check "node"   "node --version"
check "npm"    "npm --version"
# `claude --version` actually launches the binary (not just a path
# lookup), so this catches "installed but broken" failure modes that
# a simple `command -v claude` would miss. We deliberately do NOT
# add a `|| ...` fallback here -- if claude --version fails for any
# reason, this check should fail, not silently report OK.
check "claude" "claude --version"

echo
if [ "$ok" -eq 1 ]; then
  cat <<'DONE'
============================================
 Setup complete! All checks passed.
============================================

 What to do now:
   1. In this terminal, type:  claude
      (first time will ask you to log in)

 If 'claude' is not found, open a new
 terminal window and try again.

 Log saved to: setup-mac.log

DONE

  # If we discovered an orphaned Homebrew install during this run, the
  # user's *future* terminals still won't have brew on PATH unless we
  # add the shellenv line to their shell config. Offer to do it for
  # them. Use an unquoted heredoc so $BREW_BIN and $RC_FILE expand to
  # the actual values we discovered/configured.
  if [ "$BREW_WAS_ORPHANED" -eq 1 ]; then
    cat <<EOF
 ------------------------------------------------
 Heads up: Homebrew was installed but not on your
 shell PATH. We sourced it for THIS script, but
 in future terminal windows 'brew' will not be
 found unless we add this line to $RC_FILE:

     eval "\$($BREW_BIN shellenv)"

 (Detected shell: $SHELL_NAME)

EOF
    if prompt_yn " Add it to $RC_FILE now?" "Y"; then
      add_brew_to_shell_rc || say "   You can add it manually later if needed."
    else
      cat <<EOF

   OK, skipping. You can do it yourself any time with:

     echo 'eval "\$($BREW_BIN shellenv)"' >> $RC_FILE

EOF
    fi
    echo " ------------------------------------------------"
    echo
  fi
  exit "$EX_OK"
else
  cat <<'BAD'
============================================
 Setup had errors. See messages above.
 Log saved to: setup-mac.log
============================================

BAD
  exit "$EX_FAIL"
fi
